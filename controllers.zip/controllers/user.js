var express = require('express');
var userloginModel = require.main.require('./model/userlogin-model');
var router = express.Router();


//ROUTES

router.get('*', function(req, res, next){
	if(req.session.un != null){
		next();
	}else{
		res.redirect('/user');
	}
});

router.get('/', function(req, res){
	
	userloginModel.getAll(function(results){
		var data = {
			name: req.session.un,
			uList: results
		};
		res.render('user/index', data);
	});
});
router.get('/profile', function(req, res){

	userloginModel.get(req.session.uid, function(result){

		if(result != ""){
			res.render('user/profile', result);
		}else{
			res.redirect('/user');
		}
	});
});


 router.get('/comment', function(req, res){
	 res.render('user/comment');
 });
router.get('/comment', function(req, res){

	userloginModel.get(req.session.uid, function(result){

		if(result != ""){
			res.render('user/comment', result);
		}else{
			res.redirect('/user');
		}
	});
});






//////////////////////


 

router.get('/edit/:id', function(req, res){

	userModel.get(req.params.id, function(result){

		if(result != ""){
			res.render('user/edit', result);
		}else{
			res.redirect('/user/cususerlist');
		}
	});
});

router.post("/edit/:id", function(req, res){

	 
	
	var user = {
		id:req.body.id,
		fname:req.body.fname,
		///lname:req.body.lname,
		mobile:req.body.mobile,
		email: req.body.email,
		pass:req.body.pass
		
	};

	userModel.update(user, function(status){

		if(status){
			res.redirect('/user/cususerlist');
		}else{
			res.redirect('/user/edit:'+req.params.id);
		}
	});
});

router.get('/delete/:id', function(req, res){

	userModel.get(req.params.id, function(result){

		if(result != ""){
			res.render('user/delete', result);
		}else{
			res.redirect('/user/cususerlist');
		}
	});
});

router.post("/delete/:id", function(req, res){

	var user = {
		id:req.body.id,
		fname:req.body.fname,
		///lname:req.body.lname,
		mobile:req.body.mobile,
		email: req.body.email,
		pass:req.body.pass
		
	};

	userModel.delete(user, function(status){

		if(status){
			res.redirect('/user/cususerlist');
		}else{
			res.redirect('/user/delete:'+req.params.id);
		}
	});
});
module.exports = router;






